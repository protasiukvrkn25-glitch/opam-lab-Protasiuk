using System;
using System.Collections.Generic;

class IntStack
{
    private int[] items;
    private int count;

    public int Count => count;
    public int Capacity => items.Length;

    public IntStack(int capacity = 2)
    {
        if (capacity < 1) capacity = 1;
        items = new int[capacity];
        count = 0;
    }

    public void Push(int x)
    {
        if (count == items.Length)
        {
            int[] larger = new int[items.Length * 2];
            Array.Copy(items, larger, items.Length);
            items = larger;
        }

        items[count] = x;
        count++;
    }

    public int Pop()
    {
        if (count == 0)
            throw new InvalidOperationException("Стек порожній.");

        count--;
        return items[count];
    }

    public int Peek()
    {
        if (count == 0)
            throw new InvalidOperationException("Стек порожній.");

        return items[count - 1];
    }
}

class Program
{
    private const int N = 20;
    private const int K = 20;
    private const int A = 2;
    private const int B = 0;
    private const int C = 0;

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine($"N = {N}, K = {K}, a = {A}, b = {B}, c = {C}");
        Console.WriteLine("\n=== Завдання 1. Перевірка дужок ===");
        RunBracketTests();

        Console.WriteLine("\n=== Завдання 2. Зворотний польський запис ===");
        RunExpressionTests();

        Console.WriteLine("\n=== Завдання 3. Обслуговування заявок ===");
        SimulateQueue(8 + K % 5, N);

        Console.WriteLine("\n=== Завдання 4. Власний стек ===");
        TestCustomStack();

        Console.WriteLine("\n=== Завдання 5. Перевірка завдання 1 власним стеком ===");
        string[] customTests = { "(a[b]{c})", "([)]", ")(", "((", "", "\"([{}])\"" };
        foreach (string s in customTests)
        {
            bool standard = CheckBrackets(s, A, out int standardError);
            bool custom = CheckBracketsCustom(s, A, out int customError);
            Console.WriteLine($"\"{s}\" -> стандартний: {standard}, індекс {standardError}; власний: {custom}, індекс {customError}");
        }
    }

    // Завдання 1: індекс помилки — індекс першої зайвої/невідповідної закривальної
    // дужки або довжина рядка, якщо наприкінці залишилися відкривальні дужки.
    static bool CheckBrackets(string input, int variant, out int errorIndex)
    {
        Stack<(char symbol, int index)> stack = new Stack<(char, int)>();
        bool inQuotes = false;

        for (int i = 0; i < input.Length; i++)
        {
            char ch = input[i];

            if (variant == 2 && ch == '"')
            {
                inQuotes = !inQuotes;
                continue;
            }

            if (variant == 2 && inQuotes)
                continue;

            if (IsOpening(ch, variant))
            {
                stack.Push((ch, i));
            }
            else if (IsClosing(ch, variant))
            {
                if (stack.Count == 0)
                {
                    errorIndex = i;
                    return false;
                }

                var top = stack.Pop();
                if (!Matches(top.symbol, ch))
                {
                    errorIndex = i;
                    return false;
                }
            }
        }

        if (inQuotes)
        {
            errorIndex = input.Length;
            return false;
        }

        if (stack.Count > 0)
        {
            errorIndex = input.Length;
            return false;
        }

        errorIndex = -1;
        return true;
    }

    static bool IsOpening(char ch, int variant) =>
        ch == '(' || ch == '[' || ch == '{' || (variant == 1 && ch == '<');

    static bool IsClosing(char ch, int variant) =>
        ch == ')' || ch == ']' || ch == '}' || (variant == 1 && ch == '>');

    static bool Matches(char open, char close) =>
        (open == '(' && close == ')') ||
        (open == '[' && close == ']') ||
        (open == '{' && close == '}') ||
        (open == '<' && close == '>');

    static bool CheckBracketsCustom(string input, int variant, out int errorIndex)
    {
        IntStack stack = new IntStack(Math.Max(2, input.Length));
        bool inQuotes = false;

        for (int i = 0; i < input.Length; i++)
        {
            char ch = input[i];

            if (variant == 2 && ch == '"')
            {
                inQuotes = !inQuotes;
                continue;
            }

            if (variant == 2 && inQuotes)
                continue;

            if (IsOpening(ch, variant))
            {
                stack.Push((i << 16) | ch);
            }
            else if (IsClosing(ch, variant))
            {
                if (stack.Count == 0)
                {
                    errorIndex = i;
                    return false;
                }

                int packed = stack.Pop();
                char open = (char)(packed & 0xFFFF);
                if (!Matches(open, ch))
                {
                    errorIndex = i;
                    return false;
                }
            }
        }

        if (inQuotes || stack.Count > 0)
        {
            errorIndex = input.Length;
            return false;
        }

        errorIndex = -1;
        return true;
    }

    static void RunBracketTests()
    {
        string[] tests = { "(a[b]{c})", "([)]", ")(", "((", "", "\"([{}])\"" };
        foreach (string s in tests)
        {
            bool ok = CheckBrackets(s, A, out int error);
            Console.WriteLine($"\"{s}\" -> {(ok ? "збалансований" : "незбалансований")}, індекс помилки: {error}");
        }

        string manyOpen = new string('(', K) + new string(')', K - 1);
        bool result = CheckBrackets(manyOpen, A, out int index);
        Console.WriteLine($"Тест K={K}: відкривальних {K}, закривальних {K - 1}; результат: {result}, індекс помилки: {index}");
    }

    // Завдання 2: обчислення RPN без готових парсерів і LINQ.
    static bool EvaluateRpn(string expression, int variant, out double result, out string error)
    {
        Stack<double> stack = new Stack<double>();
        string[] tokens = expression.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        foreach (string token in tokens)
        {
            if (double.TryParse(token, System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out double number))
            {
                stack.Push(number);
                continue;
            }

            if (!IsOperator(token, variant))
            {
                result = 0;
                error = $"Невідомий токен: {token}";
                return false;
            }

            if (stack.Count < 2)
            {
                result = 0;
                error = $"Для операції {token} бракує чисел.";
                return false;
            }

            double right = stack.Pop();
            double left = stack.Pop();

            switch (token)
            {
                case "+":
                    stack.Push(left + right);
                    break;
                case "-":
                    stack.Push(left - right);
                    break;
                case "*":
                    stack.Push(left * right);
                    break;
                case "/":
                    if (right == 0)
                    {
                        result = 0;
                        error = "Ділення на нуль заборонене.";
                        return false;
                    }
                    stack.Push(left / right);
                    break;
                case "%":
                    if (right == 0)
                    {
                        result = 0;
                        error = "Остача від ділення на нуль не визначена.";
                        return false;
                    }
                    stack.Push(left % right);
                    break;
                case "^":
                    stack.Push(Math.Pow(left, right));
                    break;
                case "min":
                    stack.Push(Math.Min(left, right));
                    break;
                case "max":
                    stack.Push(Math.Max(left, right));
                    break;
            }
        }

        if (stack.Count != 1)
        {
            result = 0;
            error = stack.Count == 0
                ? "Вираз порожній або не містить результату."
                : "Забагато чисел: після обчислення в стеку має залишитися одне значення.";
            return false;
        }

        result = stack.Pop();
        error = "";
        return true;
    }

    static bool IsOperator(string token, int variant)
    {
        if (token == "+" || token == "-" || token == "*" || token == "/")
            return true;
        if (variant == 1 && token == "%") return true;
        if (variant == 2 && token == "^") return true;
        if (variant == 3 && (token == "min" || token == "max")) return true;
        return false;
    }

    static void PrintExpression(string expression)
    {
        if (EvaluateRpn(expression, B, out double value, out string error))
            Console.WriteLine($"{expression} -> {value.ToString(System.Globalization.CultureInfo.InvariantCulture)}");
        else
            Console.WriteLine($"{expression} -> ПОМИЛКА: {error}");
    }

    static void RunExpressionTests()
    {
        PrintExpression("3 4 + 2 *");
        PrintExpression("5 3 -");
        PrintExpression("8 2 /");
        PrintExpression("2 3 4 * +");
        PrintExpression("5 0 /");
        PrintExpression("abc 2 +");
        PrintExpression("2 3");
        PrintExpression("2 +");
        PrintExpression("");

        string ownExpression = "2 3 * 4 + 10 +";
        PrintExpression(ownExpression);
    }

    // Завдання 3: усі заявки в черзі з початку, один обслуговувач.
    static void SimulateQueue(int requestCount, int seed)
    {
        Queue<int> queue = new Queue<int>();
        Random random = new Random(seed);

        for (int i = 0; i < requestCount; i++)
            queue.Enqueue(random.Next(1, 10));

        int maxQueueLength = queue.Count;
        int currentTime = 0;
        int requestNumber = 1;

        Console.WriteLine("№ заявки | Вага | Початок | Завершення");
        while (queue.Count > 0)
        {
            if (queue.Count > maxQueueLength)
                maxQueueLength = queue.Count;

            if (queue.Count == 0)
                break;

            int weight = queue.Dequeue();
            int start = currentTime;
            currentTime += weight;
            Console.WriteLine($"{requestNumber,8} | {weight,4} | {start,7} | {currentTime,10}");
            requestNumber++;
        }

        Console.WriteLine($"Максимальна довжина черги: {maxQueueLength}");
        Console.WriteLine($"Загальний час обслуговування: {currentTime} хв");
    }

    static void TestCustomStack()
    {
        IntStack stack = new IntStack(K % 4 + 2);
        int pushes = K % 4 + 3;

        for (int i = 1; i <= pushes; i++)
        {
            stack.Push(i * 10);
            Console.WriteLine($"Після Push({i * 10}): Count = {stack.Count}, Capacity = {stack.Capacity}");
        }

        Console.WriteLine($"Peek = {stack.Peek()}");
        Console.WriteLine($"Pop = {stack.Pop()}");
        Console.WriteLine($"Після Pop: Count = {stack.Count}, Capacity = {stack.Capacity}");

        IntStack empty = new IntStack();
        try
        {
            empty.Pop();
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"Pop порожнього стека: {ex.Message}");
        }
    }
}
